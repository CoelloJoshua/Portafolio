
//Ejercico 1
// let cantidadDeGatos = 4;
// let emoji_1 = "😺";
// let emoji_2 = "😸";
// let emoji_3 = "😹";
// let gato;
// for (let i = 1; i <= cantidadDeGatos; i++) {
//    if (i % 3 == 1) {
//    gato = emoji_1
// } else if (i % 3 == 2) {
//     gato = emoji_2;
// } else if (i % 3 == 0) {
//     gato = emoji_3;
// }
// console.log( "Gato #", i , ":", gato )
// }

//Ejercicio 2

// let cantidadDeGatos = 5;
// let cantidadDePasos = 3;
// let gato = "🐈";
// let pasos = "🐾";
// for (let i = 1; i <= cantidadDeGatos; i++) {
//     let result = pasos.repeat(cantidadDePasos);
//     console.log( "Gato #", i , ":", gato, result)
//}
//Ejercicio 3

let cantidadDeGatos = 5;
let cantidadDePasos = 3;
let gato = "🐈";
let pasos = "🐾";
let gato_Azul = "🐈‍⬛";
let gato_0 ;
for (let i = 1; i <= cantidadDeGatos; i++) {
    let result = pasos.repeat(cantidadDePasos);

    if (i % 2 == 1) {
       gato_0 = gato;
    } else if (i %  2 == 0) {
        gato_0 = gato_Azul;
    }

    console.log( "Gato #", i , ":", gato_0, result)

}